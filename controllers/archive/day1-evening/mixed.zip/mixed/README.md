# Combined Myo recordings

Recordings from both people, grouped by gesture. Originals remain in the parent folder.
N__ and S__ filenames identify the person. The first 1 second (200 samples at 200 Hz) has been removed from every copy. Recordings remain separate for honest testing.

The trainer recognizes trimmed_start_seconds and does not remove the first second twice.
It still removes the final 0.5 seconds before creating windows.

Train: `python examples/myo_learning.py train --data data/mixed --model models/myo_multi.joblib`
